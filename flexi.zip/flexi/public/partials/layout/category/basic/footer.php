</div>
</div>
<div style="clear: both; display: block; position: relative;"></div>
<?php
if (0 == $count_category) {
 echo '<div id="flexi_no_record" class="flexi_alert-box flexi_notice">' . __('No category', 'flexi') . '</div>';
}

?>